"""
sorting.py - Phase 2 (part 1): Parcel prioritisation.

Merge Sort is used because:
  * it is O(n log n) in the best, average AND worst case,
  * it is stable (parcels with equal keys keep their original order),
  * it handles any key (we sort by a tuple: deadline, then priority).

bubble_sort() is included ONLY for the performance comparison in Phase 4,
to show why a good algorithm matters.
"""


def merge_sort(items, key=lambda x: x):
    """Return a NEW sorted list (ascending by key). Time O(n log n), Space O(n)."""
    if len(items) <= 1:
        return list(items)

    mid = len(items) // 2
    left = merge_sort(items[:mid], key)
    right = merge_sort(items[mid:], key)
    return _merge(left, right, key)


def _merge(left, right, key):
    """Merge two already-sorted lists into one sorted list."""
    merged = []
    i = j = 0
    while i < len(left) and j < len(right):
        # '<=' keeps the sort stable (left item wins on ties)
        if key(left[i]) <= key(right[j]):
            merged.append(left[i])
            i += 1
        else:
            merged.append(right[j])
            j += 1
    merged.extend(left[i:])
    merged.extend(right[j:])
    return merged


def bubble_sort(items, key=lambda x: x):
    """Slow O(n^2) sort - used only as a baseline in benchmarks."""
    arr = list(items)
    n = len(arr)
    for i in range(n - 1):
        swapped = False
        for j in range(n - 1 - i):
            if key(arr[j]) > key(arr[j + 1]):
                arr[j], arr[j + 1] = arr[j + 1], arr[j]
                swapped = True
        if not swapped:
            break
    return arr


def prioritise_parcels(parcels):
    """
    Sort parcels: earliest deadline first; if deadlines tie, HIGHER priority first.
    (Priority is negated so that a bigger priority sorts earlier.)
    """
    return merge_sort(parcels, key=lambda p: (p["deadline"], -p["priority"]))
