"""
graph.py - Phase 3: Route Maker and Graph Processing.

Graph format: adjacency list  ->  {node: [(neighbour, distance_km), ...]}
Node 0 is always the DEPOT (courier hub). Other nodes are customer locations.

* dijkstra()          - single-source shortest paths (min-heap version)
* build_distance_matrix() - runs Dijkstra from every stop we need to visit
* nearest_neighbor_tsp()  - greedy approximation for the visiting order
* brute_force_tsp()       - exact answer for tiny inputs (to measure quality)
"""
import heapq
import itertools

INF = float("inf")


def dijkstra(graph, source):
    """
    Returns (dist, parent).
      dist[v]   = shortest distance from source to v
      parent[v] = previous node on that shortest path
    Time O((V + E) log V) with a binary heap.
    """
    dist = {node: INF for node in graph}
    parent = {node: None for node in graph}
    dist[source] = 0
    heap = [(0, source)]

    while heap:
        d, u = heapq.heappop(heap)
        if d > dist[u]:               # stale entry, a better one was already processed
            continue
        for v, w in graph[u]:
            nd = d + w
            if nd < dist[v]:
                dist[v] = nd
                parent[v] = u
                heapq.heappush(heap, (nd, v))
    return dist, parent


def get_path(parent, target):
    """Rebuild the node-by-node path from the parent array."""
    path = []
    while target is not None:
        path.append(target)
        target = parent[target]
    return path[::-1]


def build_distance_matrix(graph, stops):
    """
    Run Dijkstra from each stop and keep only distances between stops.
    Returns (matrix, parents) where matrix[a][b] = shortest distance a -> b
    and parents[a] is the Dijkstra parent array for source a.
    """
    matrix, parents = {}, {}
    for s in stops:
        dist, parent = dijkstra(graph, s)
        matrix[s] = {t: dist[t] for t in stops}
        parents[s] = parent
    return matrix, parents


def nearest_neighbor_tsp(matrix, stops, start=0):
    """
    Greedy TSP approximation: from the current stop always go to the closest
    unvisited stop, then return to the start (depot).
    Time O(k^2) for k stops.  Returns (route, total_length).
    """
    unvisited = set(stops) - {start}
    route = [start]
    total = 0
    current = start
    while unvisited:
        nxt = min(unvisited, key=lambda s: matrix[current][s])
        total += matrix[current][nxt]
        route.append(nxt)
        unvisited.remove(nxt)
        current = nxt
    total += matrix[current][start]       # come back to depot
    route.append(start)
    return route, total


def route_length(matrix, route):
    return sum(matrix[route[i]][route[i + 1]] for i in range(len(route) - 1))


def brute_force_tsp(matrix, stops, start=0):
    """Exact optimal tour - only practical for <= ~9 stops (k! permutations)."""
    others = [s for s in stops if s != start]
    best_route, best_len = None, INF
    for perm in itertools.permutations(others):
        r = [start, *perm, start]
        length = route_length(matrix, r)
        if length < best_len:
            best_route, best_len = r, length
    return best_route, best_len


def expand_full_path(parents, route):
    """Turn the stop-to-stop route into the full list of nodes actually driven."""
    full = [route[0]]
    for a, b in zip(route, route[1:]):
        leg = get_path(parents[a], b)
        full.extend(leg[1:])
    return full
