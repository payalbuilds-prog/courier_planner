# Mini-Courier Planner

**Course:** Design & Analysis of Algorithms (ETCCDA302) - Capstone Assignment
**University:** K.R. Mangalam University, Gurugram
**Faculty:** Dr. Shweta Agarwal
**Student:** Payal Chauhan (Roll No. 2501201050)
**Language:** Python 3.8+

---

## 1. What this project does

Given a list of parcels and a road network, the planner:

1. **Prioritises** parcels (Merge Sort),
2. **Fills the van** with the best set of parcels for one trip (0/1 Knapsack - Dynamic Programming),
3. **Finds shortest paths** between delivery points (Dijkstra),
4. **Plans the delivery route** (Nearest-Neighbor TSP approximation),
5. **Measures runtime** of each step on small and large inputs.

```
Parcels --> Merge Sort --> Knapsack DP --> Selected parcels --> Dijkstra --> Nearest-Neighbor TSP --> Route
 (list)    (priority)     (fit van)        (their destinations)   (distances)    (visit order)         (km)
```

## 2. Phase 1 - Problem design

### Data design
**Parcel** (Python dict):

| Field | Meaning | Range |
|---|---|---|
| `id` | Parcel ID, e.g. `P003` | - |
| `weight` | Weight in kg | 1 - 15 |
| `priority` | Importance (used as the knapsack *value*) | 1 - 10 |
| `deadline` | Hours left to deliver | 1 - 24 |
| `destination` | Graph node where it must go | 1 .. N-1 |

**Graph:** undirected, weighted, stored as an adjacency list
`{node: [(neighbour, distance_km), ...]}`. **Node 0 is the depot** (courier hub); all other nodes are customer locations. Graphs are always connected.

**Van capacity:** a single weight limit `W` (kg) per trip.

### Algorithm selection

| Step | Algorithm | Why this one | Complexity |
|---|---|---|---|
| Prioritise | Merge Sort | Guaranteed O(n log n), stable, handles tuple keys (deadline, -priority) | O(n log n) time, O(n) space |
| Pick parcels | 0/1 Knapsack (DP) | Each parcel is taken whole or not at all; we want max total priority under weight limit | O(n.W) time & space |
| Shortest paths | Dijkstra (min-heap) | All road distances are positive | O((V+E) log V) per run |
| Visit order | Nearest-Neighbor TSP | Exact TSP is NP-hard (O(k!)); NN is a fast, simple approximation | O(k^2) |

### How the pieces work together
- Sorting orders parcels by **earliest deadline first**; ties are broken by **higher priority first**.
- Knapsack then selects which parcels fit in the van, maximising total priority.
- The destinations of the selected parcels (plus the depot) become the **stops**.
- Dijkstra runs from every stop to build a stop-to-stop **distance matrix**.
- Nearest-Neighbor uses that matrix to decide the visiting order and returns to the depot.

## 3. Project structure

```
courier_planner/
|-- main.py              integrated demo (full pipeline)
|-- sorting.py           merge sort (+ bubble sort for comparison)
|-- knapsack.py          0/1 knapsack DP (2D table + 1D optimised)
|-- graph.py             Dijkstra, distance matrix, nearest-neighbor TSP, brute force
|-- data_gen.py          reproducible dataset generator / loader
|-- benchmark.py         Phase 4 runtime tests + charts
|-- tests.py             47 correctness checks
|-- make_screenshots.py  renders program output into screenshots/
|-- data/                sample_small / sample_medium / sample_large .json, benchmark_results.csv
|-- charts/              runtime_chart.png, step_share_chart.png, sort_comparison.png
|-- screenshots/         output evidence (PNG)
|-- requirements.txt
`-- README.md
```

## 4. How to run

```bash
pip install -r requirements.txt        # only needed for charts (matplotlib)

python data_gen.py                     # (optional) regenerate sample datasets
python main.py                         # demo on the small dataset (prints DP table)
python main.py data/sample_medium.json # 100 parcels
python main.py data/sample_large.json  # 500 parcels
python tests.py                        # correctness checks
python benchmark.py                    # runtime tests + charts
python make_screenshots.py             # (optional) re-create screenshots
```

## 5. Sample results (data/sample_small.json - 10 parcels, 30 kg van)

**Sorted order (deadline asc, priority desc):**
`P003, P008, P006, P009, P004, P010, P005, P007, P001, P002`

**Knapsack result:** selected `P003, P008, P006, P010, P002` -> weight **28/30 kg**, total priority **38**. The other 5 parcels stay at the depot for the next trip.

**Delivery stops:** depot 0 and nodes 1, 3, 5, 7.

**Route:** `0 -> 3 -> 5 -> 7 -> 1 -> 0`, total **30 km**.
Brute-force optimal is also 30 km, so on this input Nearest-Neighbor found the optimum.

**Medium dataset (100 parcels, 120 kg):** 31 parcels loaded (priority 237, 120/120 kg), 20 stops, route 221 km.

Screenshots of all outputs are in `screenshots/`.

## 6. Phase 4 - Performance testing

Each size was run 3 times with different random seeds and averaged. Correctness assertions (sorted order, weight limit, valid route) run inside every benchmark iteration.

| Parcels | Stops | Sort (ms) | Knapsack (ms) | Dijkstra (ms) | TSP (ms) | Total (ms) |
|---:|---:|---:|---:|---:|---:|---:|
| 10 | 5 | 0.03 | 0.03 | 0.05 | 0.01 | 0.11 |
| 50 | 15 | 0.13 | 0.58 | 0.50 | 0.03 | 1.24 |
| 100 | 28 | 0.32 | 2.28 | 1.69 | 0.10 | 4.38 |
| 200 | 59 | 0.68 | 9.17 | 6.65 | 0.24 | 16.74 |
| 500 | 142 | 1.21 | 49.45 | 42.05 | 1.24 | 93.94 |
| 1000 | 286 | 3.07 | 262.64 | 164.57 | 3.49 | 433.77 |

(Exact timings vary a little between runs and machines. Raw numbers are in `data/benchmark_results.csv`.)

Charts: `charts/runtime_chart.png` (runtime vs n, log scale), `charts/step_share_chart.png` (which step dominates), `charts/sort_comparison.png` (Merge vs Bubble vs Python `sorted`).

### Observations
- **Knapsack DP and Dijkstra dominate** the runtime (together >90% at n = 1000). Sorting and TSP are tiny in comparison.
- Knapsack grows with n x W (capacity was set to 2n here, so it grows roughly quadratically). Dijkstra cost grows because the number of stops (and so the number of Dijkstra runs) grows with n.
- **Merge Sort vs Bubble Sort:** at n = 4000, Merge Sort took about 12 ms and Bubble Sort about 1500 ms - this is O(n log n) vs O(n^2) in practice. Python's built-in `sorted()` (Timsort, written in C) is faster still.
- **Nearest-Neighbor quality:** it is a heuristic, not optimal. On small cases it is verified against brute force (`tests.py` checks NN length >= optimal length; on the demo dataset it matched the optimum).

### Optimisation ideas
1. **Knapsack memory:** a 1D array (`knapsack_value_only`) cuts space from O(n.W) to O(W). It gives the same answer (tested) but cannot backtrack which parcels were chosen, and in Python it was not faster in time - the saving is memory only.
2. **Dijkstra:** run it only from stops that are needed (already done), or run Floyd-Warshall once if the same graph is reused for many trips. For huge graphs, use A* or multi-threaded runs.
3. **TSP quality:** improve the NN route with **2-opt** local search, or use Christofides / dynamic programming (Held-Karp) for up to ~20 stops.
4. **Multiple trips:** repeat the pipeline on the left-over parcels until all are delivered.
5. **Use C-backed libraries** (NumPy for the DP table) to speed up the knapsack inner loop.

## 7. Correctness testing (tests.py - 47 checks, all passing)
- Merge Sort and Bubble Sort equal Python's `sorted()` for n = 0, 1, 2, 10, 500; Merge Sort is stable.
- Parcel order follows (deadline asc, priority desc).
- Knapsack gives 9 on the textbook example, equals brute force on 5 random inputs, never exceeds capacity, and the 1D version agrees with the 2D version.
- Dijkstra matches a hand-solved graph; generated graphs are connected.
- NN route visits every stop exactly once, starts/ends at the depot, its length is recomputed correctly and is never shorter than the brute-force optimum.

## 8. Assumptions and limitations
- Roads are undirected with positive integer distances (a requirement for Dijkstra).
- Knapsack *value* = parcel priority; deadlines influence sorting only.
- One van, one trip. Parcels that do not fit are left for later trips.
- Weights and capacity are integers (needed for the DP table).
- Nearest-Neighbor does not guarantee the shortest route.

## 9. Viva quick notes
- **Why Merge Sort?** Always O(n log n), stable.
- **Why DP and not greedy for packing?** Greedy (by priority or ratio) can miss the optimal combination; DP checks every weight limit systematically.
- **Why is the DP table O(n.W)?** n+1 rows x W+1 columns, each cell O(1).
- **How do we know which parcels were chosen?** Backtrack from `dp[n][W]`: if `dp[i][w] != dp[i-1][w]`, parcel i was taken.
- **Why Dijkstra fails with negative edges?** It assumes a settled node can never be improved.
- **Why is TSP approximated?** Exact solution needs checking (k-1)! tours.
- **Can NN be bad?** Yes - it can pick a close stop now and force a very long jump later.
