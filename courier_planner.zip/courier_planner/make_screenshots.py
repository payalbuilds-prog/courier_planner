"""
make_screenshots.py - renders terminal output of the program into PNG images
(so output evidence exists in screenshots/ folder). Run: python make_screenshots.py
"""
import subprocess
import sys

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt


def run(cmd):
    return subprocess.run([sys.executable, *cmd], capture_output=True, text=True).stdout


def render(text, filename, title):
    lines = text.rstrip("\n").split("\n")
    width = max(len(l) for l in lines)
    fig_w = max(8, width * 0.092)
    fig_h = max(2, len(lines) * 0.2 + 0.7)
    fig = plt.figure(figsize=(fig_w, fig_h), facecolor="#1e1e1e")
    fig.text(0.01, 1 - 0.25 / fig_h, f"$ {title}", color="#7ee787", family="monospace",
             fontsize=9, va="top")
    fig.text(0.01, 1 - 0.6 / fig_h, "\n".join(lines), color="#e6e6e6",
             family="monospace", fontsize=8, va="top", linespacing=1.35)
    fig.savefig(f"screenshots/{filename}", dpi=140, facecolor=fig.get_facecolor())
    plt.close(fig)
    print("saved", filename)


def section(text, start_marker, end_marker=None):
    start = text.index(start_marker)
    start = text.rfind("=" * 64, 0, start)
    if end_marker:
        end = text.index(end_marker)
        end = text.rfind("=" * 64, 0, end)
        return text[start:end]
    return text[start:]


out = run(["main.py"])
render(out[:out.index("=" * 64, out.index("STEP 2") - 70)].strip("\n"),
       "01_input_and_sorting.png", "python main.py   (part 1: input + merge sort)")
render(section(out, "STEP 2", "STEP 3").strip("\n"),
       "02_knapsack_dp.png", "python main.py   (part 2: knapsack DP table + selection)")
render(section(out, "STEP 3").strip("\n"),
       "03_dijkstra_route.png", "python main.py   (part 3: Dijkstra + nearest-neighbor route)")
render(run(["tests.py"]), "04_tests_passed.png", "python tests.py")
render(run(["benchmark.py"]), "05_benchmark_output.png", "python benchmark.py")
render(run(["main.py", "data/sample_medium.json"]), "06_medium_dataset_run.png",
       "python main.py data/sample_medium.json")
