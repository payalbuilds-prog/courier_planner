"""
benchmark.py - Phase 4: Performance testing and optimisation evidence.

Times every major step for growing input sizes, saves:
  charts/runtime_chart.png      - runtime of each step vs number of parcels
  charts/step_share_chart.png   - which step dominates at the largest size
  charts/sort_comparison.png    - Merge Sort vs Bubble Sort vs Python sorted()
  data/benchmark_results.csv    - raw numbers

Run: python benchmark.py
"""
import csv
import time

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from data_gen import generate_graph, generate_parcels
from sorting import prioritise_parcels, merge_sort, bubble_sort
from knapsack import knapsack, knapsack_value_only
from graph import build_distance_matrix, nearest_neighbor_tsp

SIZES = [10, 50, 100, 200, 500, 1000]
REPEATS = 3


def timed(fn, *args):
    t = time.perf_counter()
    out = fn(*args)
    return out, time.perf_counter() - t


def run_pipeline(n, seed):
    """One full pipeline run; returns timings (seconds) of each step + result info."""
    nodes = max(10, n // 2)
    capacity = 2 * n
    parcels = generate_parcels(n, nodes, seed)
    graph = generate_graph(nodes, seed)

    sorted_p, t_sort = timed(prioritise_parcels, parcels)
    (value, selected, _), t_knap = timed(knapsack, sorted_p, capacity)
    stops = sorted({0} | {p["destination"] for p in selected})
    (matrix, _), t_dij = timed(build_distance_matrix, graph, stops)
    (route, length), t_tsp = timed(nearest_neighbor_tsp, matrix, stops)

    # correctness evidence for this run
    assert all((a["deadline"], -a["priority"]) <= (b["deadline"], -b["priority"])
               for a, b in zip(sorted_p, sorted_p[1:])), "sort wrong"
    assert sum(p["weight"] for p in selected) <= capacity, "overweight"
    assert sorted(route[:-1]) == stops and route[-1] == 0, "bad route"

    return {"sort": t_sort, "knapsack": t_knap, "dijkstra": t_dij, "tsp": t_tsp,
            "stops": len(stops), "selected": len(selected), "length": length}


def main():
    steps = ["sort", "knapsack", "dijkstra", "tsp"]
    results = []
    print(f"{'n':>6}{'stops':>7}{'sort ms':>11}{'knap ms':>11}{'dijk ms':>11}{'tsp ms':>11}{'total ms':>11}")
    for n in SIZES:
        runs = [run_pipeline(n, seed=100 + r) for r in range(REPEATS)]
        avg = {s: sum(r[s] for r in runs) / REPEATS * 1000 for s in steps}
        avg["total"] = sum(avg.values())
        avg["n"] = n
        avg["stops"] = round(sum(r["stops"] for r in runs) / REPEATS)
        results.append(avg)
        print(f"{n:>6}{avg['stops']:>7}{avg['sort']:>11.3f}{avg['knapsack']:>11.3f}"
              f"{avg['dijkstra']:>11.3f}{avg['tsp']:>11.3f}{avg['total']:>11.3f}")

    with open("data/benchmark_results.csv", "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["parcels", "stops", "sort_ms", "knapsack_ms", "dijkstra_ms", "tsp_ms", "total_ms"])
        for r in results:
            w.writerow([r["n"], r["stops"], *(round(r[s], 4) for s in steps), round(r["total"], 4)])

    # ---------- chart 1: runtime vs size ----------
    plt.figure(figsize=(8, 5))
    labels = {"sort": "Merge Sort", "knapsack": "Knapsack DP",
              "dijkstra": "Dijkstra (all stops)", "tsp": "Nearest-Neighbor TSP"}
    for s in steps:
        plt.plot(SIZES, [r[s] for r in results], marker="o", label=labels[s])
    plt.plot(SIZES, [r["total"] for r in results], "k--", marker="s", label="Total")
    plt.xlabel("Number of parcels (n)")
    plt.ylabel("Average runtime (ms)")
    plt.yscale("log")
    plt.title("Mini-Courier Planner: runtime of each step vs input size")
    plt.grid(True, which="both", alpha=0.3)
    plt.legend()
    plt.tight_layout()
    plt.savefig("charts/runtime_chart.png", dpi=150)
    plt.close()

    # ---------- chart 2: share of time at the largest size ----------
    big = results[-1]
    plt.figure(figsize=(6, 4))
    vals = [big[s] for s in steps]
    bars = plt.bar([labels[s] for s in steps], vals, color=["#4c72b0", "#dd8452", "#55a868", "#c44e52"])
    for b, v in zip(bars, vals):
        plt.text(b.get_x() + b.get_width() / 2, v, f"{v:.1f} ms", ha="center", va="bottom", fontsize=8)
    plt.ylabel("Runtime (ms)")
    plt.title(f"Where does the time go? (n = {SIZES[-1]} parcels)")
    plt.xticks(rotation=15, fontsize=8)
    plt.tight_layout()
    plt.savefig("charts/step_share_chart.png", dpi=150)
    plt.close()

    # ---------- sorting comparison ----------
    print("\nSorting comparison (ms)")
    sort_sizes = [100, 500, 1000, 2000, 4000]
    t_merge, t_bubble, t_py = [], [], []
    for n in sort_sizes:
        data = generate_parcels(n, 50, seed=5)
        key = lambda p: (p["deadline"], -p["priority"])
        _, a = timed(merge_sort, data, key)
        _, b = timed(bubble_sort, data, key)
        _, c = timed(lambda d, k: sorted(d, key=k), data, key)
        t_merge.append(a * 1000); t_bubble.append(b * 1000); t_py.append(c * 1000)
        print(f"n={n:>5}  merge={a*1000:9.2f}  bubble={b*1000:10.2f}  python sorted={c*1000:7.3f}")
    plt.figure(figsize=(8, 5))
    plt.plot(sort_sizes, t_bubble, marker="o", label="Bubble Sort  O(n^2)")
    plt.plot(sort_sizes, t_merge, marker="o", label="Merge Sort  O(n log n)")
    plt.plot(sort_sizes, t_py, marker="o", label="Python sorted() (Timsort)")
    plt.xlabel("Number of parcels (n)")
    plt.ylabel("Runtime (ms)")
    plt.title("Why Merge Sort? Sorting algorithm comparison")
    plt.grid(True, alpha=0.3)
    plt.legend()
    plt.tight_layout()
    plt.savefig("charts/sort_comparison.png", dpi=150)
    plt.close()

    # ---------- knapsack memory optimisation ----------
    print("\nKnapsack: 2D table vs 1D optimised (n=500, W=1000)")
    data = generate_parcels(500, 50, seed=9)
    (v2, _, _), a = timed(knapsack, data, 1000)
    v1, b = timed(knapsack_value_only, data, 1000)
    print(f"2D table: {a*1000:.1f} ms (value {v2}) | 1D array: {b*1000:.1f} ms (value {v1}) | same answer: {v1 == v2}")

    print("\nSaved: charts/runtime_chart.png, charts/step_share_chart.png, "
          "charts/sort_comparison.png, data/benchmark_results.csv")


if __name__ == "__main__":
    main()
