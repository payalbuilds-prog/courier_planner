"""
knapsack.py - Phase 2 (part 2): Box filling with Dynamic Programming.

The delivery van has a weight capacity W. Every parcel has a weight and a
priority (value). We want the set of parcels with the MAXIMUM total priority
that fits in one trip. Each parcel is either taken or left -> 0/1 Knapsack.

Recurrence:
    dp[i][w] = dp[i-1][w]                                   if weight_i > w
             = max(dp[i-1][w], value_i + dp[i-1][w-weight_i])   otherwise

Time  : O(n * W)
Space : O(n * W)   (full table kept so we can backtrack the chosen parcels)
"""


def knapsack(parcels, capacity):
    """
    Returns (best_value, selected_parcels, dp_table).
    selected_parcels is a list of parcel dicts.
    """
    n = len(parcels)
    dp = [[0] * (capacity + 1) for _ in range(n + 1)]

    # ---- fill the table ----
    for i in range(1, n + 1):
        wt = parcels[i - 1]["weight"]
        val = parcels[i - 1]["priority"]
        for w in range(capacity + 1):
            dp[i][w] = dp[i - 1][w]                       # skip parcel i
            if wt <= w:
                take = val + dp[i - 1][w - wt]            # take parcel i
                if take > dp[i][w]:
                    dp[i][w] = take

    # ---- backtrack to find WHICH parcels were taken ----
    selected = []
    w = capacity
    for i in range(n, 0, -1):
        if dp[i][w] != dp[i - 1][w]:                      # parcel i was taken
            selected.append(parcels[i - 1])
            w -= parcels[i - 1]["weight"]
    selected.reverse()

    return dp[n][capacity], selected, dp


def knapsack_value_only(parcels, capacity):
    """Space-optimised version: O(W) memory (1D array). Used in optimisation notes."""
    dp = [0] * (capacity + 1)
    for p in parcels:
        wt, val = p["weight"], p["priority"]
        for w in range(capacity, wt - 1, -1):             # go backwards!
            dp[w] = max(dp[w], val + dp[w - wt])
    return dp[capacity]
