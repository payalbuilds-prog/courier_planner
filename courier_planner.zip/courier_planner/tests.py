"""
tests.py - correctness evidence for Phase 4.
Run: python tests.py
"""
import itertools
import random

from sorting import merge_sort, bubble_sort, prioritise_parcels
from knapsack import knapsack, knapsack_value_only
from graph import (dijkstra, build_distance_matrix, nearest_neighbor_tsp,
                   brute_force_tsp, route_length)
from data_gen import generate_graph, generate_parcels, load_dataset

passed = 0


def check(name, cond):
    global passed
    assert cond, f"FAILED: {name}"
    passed += 1
    print(f"  [PASS] {name}")


print("Sorting tests")
rnd = random.Random(0)
for n in (0, 1, 2, 10, 500):
    data = [rnd.randint(0, 100) for _ in range(n)]
    check(f"merge_sort matches sorted() for n={n}", merge_sort(data) == sorted(data))
    check(f"bubble_sort matches sorted() for n={n}", bubble_sort(data) == sorted(data))
ps = prioritise_parcels(generate_parcels(200, 20, seed=3))
check("parcels ordered by (deadline asc, priority desc)",
      all((a["deadline"], -a["priority"]) <= (b["deadline"], -b["priority"])
          for a, b in zip(ps, ps[1:])))
pairs = [(1, "a"), (0, "b"), (1, "c"), (0, "d")]
check("merge_sort is stable", merge_sort(pairs, key=lambda x: x[0]) ==
      [(0, "b"), (0, "d"), (1, "a"), (1, "c")])

print("\nKnapsack tests")
classic = [{"id": "A", "weight": 1, "priority": 1}, {"id": "B", "weight": 3, "priority": 4},
           {"id": "C", "weight": 4, "priority": 5}, {"id": "D", "weight": 5, "priority": 7}]
val, sel, _ = knapsack(classic, 7)
check("textbook example gives value 9", val == 9)
check("selected parcels add up to reported value", sum(p["priority"] for p in sel) == val)
for seed in range(5):
    items = generate_parcels(12, 10, seed=seed)
    cap = 30
    v, s, _ = knapsack(items, cap)
    brute = max(sum(p["priority"] for p in c)
                for r in range(len(items) + 1)
                for c in itertools.combinations(items, r)
                if sum(p["weight"] for p in c) <= cap)
    check(f"DP equals brute force (seed {seed})", v == brute)
    check(f"weight within capacity (seed {seed})", sum(p["weight"] for p in s) <= cap)
    check(f"1D version equals 2D version (seed {seed})", knapsack_value_only(items, cap) == v)

print("\nGraph tests")
g = {0: [(1, 4), (2, 1)], 1: [(0, 4), (2, 2), (3, 5)], 2: [(0, 1), (1, 2), (3, 8)], 3: [(1, 5), (2, 8)]}
d, _ = dijkstra(g, 0)
check("Dijkstra on hand-made graph", d == {0: 0, 1: 3, 2: 1, 3: 8})
G = generate_graph(60, seed=5)
d, _ = dijkstra(G, 0)
check("generated graph is connected", all(v < float("inf") for v in d.values()))
for seed in range(5):
    G = generate_graph(30, seed=seed)
    parcels = generate_parcels(40, 30, seed=seed)
    stops = sorted({0} | {p["destination"] for p in parcels[:6]})
    m, _ = build_distance_matrix(G, stops)
    route, length = nearest_neighbor_tsp(m, stops)
    check(f"route visits every stop once & returns to depot (seed {seed})",
          route[0] == 0 and route[-1] == 0 and sorted(route[:-1]) == stops)
    check(f"reported length matches recomputed length (seed {seed})",
          length == route_length(m, route))
    _, opt = brute_force_tsp(m, stops)
    check(f"NN length >= optimal length (seed {seed})", length >= opt)

print("\nDataset file test")
p, gr, cap = load_dataset("data/sample_small.json")
check("sample_small.json loads (10 parcels)", len(p) == 10 and cap == 30)

print(f"\nALL {passed} CHECKS PASSED")
