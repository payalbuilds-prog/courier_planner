"""
main.py - Mini-Courier Planner (integrated demo)

Pipeline:
  1. Load parcels + road graph
  2. Merge Sort  -> prioritise parcels
  3. 0/1 Knapsack DP -> choose best parcels for one trip
  4. Dijkstra -> shortest distances between all delivery stops
  5. Nearest-Neighbor TSP -> final delivery route
  6. (bonus) compare with the exact optimal route when stops are few

Run:  python main.py                      (uses data/sample_small.json)
      python main.py data/sample_medium.json
"""
import sys
import time

from data_gen import load_dataset
from sorting import prioritise_parcels
from knapsack import knapsack
from graph import (dijkstra, get_path, build_distance_matrix,
                   nearest_neighbor_tsp, brute_force_tsp, expand_full_path)


def line(title):
    print("\n" + "=" * 64)
    print(title)
    print("=" * 64)


def print_parcels(parcels):
    print(f"{'ID':<6}{'Weight':>8}{'Priority':>10}{'Deadline':>10}{'Dest':>6}")
    print("-" * 40)
    for p in parcels:
        print(f"{p['id']:<6}{p['weight']:>8}{p['priority']:>10}"
              f"{p['deadline']:>10}{p['destination']:>6}")


def print_dp_table(parcels, dp, capacity):
    """Print the DP table (only if small enough to read)."""
    if capacity > 30 or len(parcels) > 12:
        print("(DP table too large to print - shown only for small datasets)")
        return
    header = "i  parcel  " + " ".join(f"{w:>3}" for w in range(capacity + 1))
    print(header)
    print("-" * len(header))
    for i, row in enumerate(dp):
        name = "-" if i == 0 else parcels[i - 1]["id"]
        print(f"{i:<3}{name:<8}" + " ".join(f"{v:>3}" for v in row))


def main():
    path = sys.argv[1] if len(sys.argv) > 1 else "data/sample_small.json"
    parcels, graph, capacity = load_dataset(path)

    line("STEP 0: INPUT")
    print(f"Dataset      : {path}")
    print(f"Parcels      : {len(parcels)}")
    print(f"Graph nodes  : {len(graph)}  (node 0 = depot)")
    print(f"Van capacity : {capacity} kg")
    if len(parcels) <= 15:
        print_parcels(parcels)

    # ---------- Phase 2a: sorting ----------
    line("STEP 1: PARCELS SORTED (Merge Sort: earliest deadline, then highest priority)")
    t = time.perf_counter()
    sorted_parcels = prioritise_parcels(parcels)
    t_sort = time.perf_counter() - t
    if len(sorted_parcels) <= 15:
        print_parcels(sorted_parcels)
    else:
        print("Top 10 after sorting:")
        print_parcels(sorted_parcels[:10])
    print(f"\nSort time: {t_sort * 1000:.3f} ms")

    # ---------- Phase 2b: knapsack ----------
    line("STEP 2: BOX FILLING (0/1 Knapsack - Dynamic Programming)")
    t = time.perf_counter()
    best_value, selected, dp = knapsack(sorted_parcels, capacity)
    t_knap = time.perf_counter() - t
    print_dp_table(sorted_parcels, dp, capacity)
    total_wt = sum(p["weight"] for p in selected)
    print(f"\nSelected parcels : {[p['id'] for p in selected]}")
    print(f"Total weight     : {total_wt} / {capacity} kg")
    print(f"Total priority   : {best_value}")
    print(f"Left behind      : {len(parcels) - len(selected)} parcels")
    print(f"Knapsack time    : {t_knap * 1000:.3f} ms")

    # ---------- Phase 3a: Dijkstra ----------
    stops = sorted({0} | {p["destination"] for p in selected})
    line("STEP 3: SHORTEST PATHS (Dijkstra)")
    print(f"Delivery stops (incl. depot 0): {stops}")
    t = time.perf_counter()
    matrix, parents = build_distance_matrix(graph, stops)
    t_dij = time.perf_counter() - t
    dist0, parent0 = dijkstra(graph, 0)
    print("\nShortest path from DEPOT to each stop:")
    for s in stops[1:]:
        print(f"  0 -> {s:<3} : {dist0[s]:>3} km   path = {get_path(parent0, s)}")
    print(f"\nDijkstra time ({len(stops)} runs): {t_dij * 1000:.3f} ms")

    # ---------- Phase 3b: TSP ----------
    line("STEP 4: DELIVERY ROUTE (Nearest-Neighbor TSP approximation)")
    t = time.perf_counter()
    route, length = nearest_neighbor_tsp(matrix, stops, start=0)
    t_tsp = time.perf_counter() - t
    print("Route (stop order)  :", " -> ".join(map(str, route)))
    print("Full road path      :", " -> ".join(map(str, expand_full_path(parents, route))))
    print(f"Total route length  : {length} km")
    print(f"TSP time            : {t_tsp * 1000:.3f} ms")

    # leg-by-leg breakdown
    print("\nLeg breakdown:")
    for a, b in zip(route, route[1:]):
        print(f"  {a:>3} -> {b:<3} {matrix[a][b]:>3} km")

    # ---------- Bonus: quality check ----------
    if len(stops) <= 9:
        line("BONUS: HOW GOOD IS NEAREST NEIGHBOR? (vs exact brute force)")
        opt_route, opt_len = brute_force_tsp(matrix, stops, start=0)
        print("Optimal route :", " -> ".join(map(str, opt_route)), f"= {opt_len} km")
        print("NN route      :", " -> ".join(map(str, route)), f"= {length} km")
        ratio = length / opt_len if opt_len else 1
        print(f"NN is {ratio:.2f}x the optimal length "
              f"({(ratio - 1) * 100:.1f}% longer)")

    line("SUMMARY")
    print(f"{len(parcels)} parcels -> {len(selected)} loaded "
          f"(priority {best_value}, {total_wt}/{capacity} kg) -> "
          f"{len(stops) - 1} stops -> route {length} km")


if __name__ == "__main__":
    main()
