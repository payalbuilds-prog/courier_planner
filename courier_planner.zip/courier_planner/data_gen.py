"""
data_gen.py - creates parcel + graph datasets (reproducible, fixed seeds).
"""
import json
import random


def generate_graph(num_nodes, seed=1, extra_edges_factor=2):
    """
    Random CONNECTED undirected weighted graph.
    First a random spanning tree (guarantees connectivity), then extra edges.
    Returns adjacency list {node: [(nbr, km), ...]} with node 0 = depot.
    """
    rnd = random.Random(seed)
    graph = {i: [] for i in range(num_nodes)}
    existing = set()

    def add_edge(a, b, w):
        if a == b or (min(a, b), max(a, b)) in existing:
            return
        existing.add((min(a, b), max(a, b)))
        graph[a].append((b, w))
        graph[b].append((a, w))

    for v in range(1, num_nodes):                       # spanning tree
        add_edge(v, rnd.randrange(0, v), rnd.randint(2, 15))
    for _ in range(num_nodes * extra_edges_factor):     # extra roads
        a, b = rnd.randrange(num_nodes), rnd.randrange(num_nodes)
        add_edge(a, b, rnd.randint(2, 20))
    return graph


def generate_parcels(num_parcels, num_nodes, seed=1):
    """Each parcel: id, weight(kg), priority(1-10), deadline(hours), destination node."""
    rnd = random.Random(seed)
    return [
        {
            "id": f"P{i + 1:03d}",
            "weight": rnd.randint(1, 15),
            "priority": rnd.randint(1, 10),
            "deadline": rnd.randint(1, 24),
            "destination": rnd.randint(1, num_nodes - 1),
        }
        for i in range(num_parcels)
    ]


def save_dataset(path, parcels, graph, capacity):
    data = {
        "capacity": capacity,
        "parcels": parcels,
        "graph": {str(k): v for k, v in graph.items()},
    }
    with open(path, "w") as f:
        json.dump(data, f, indent=2)


def load_dataset(path):
    with open(path) as f:
        data = json.load(f)
    graph = {int(k): [tuple(e) for e in v] for k, v in data["graph"].items()}
    return data["parcels"], graph, data["capacity"]


if __name__ == "__main__":
    # small sample used for the demo / screenshots
    save_dataset("data/sample_small.json",
                 generate_parcels(10, 8, seed=7), generate_graph(8, seed=7), capacity=30)
    # medium sample
    save_dataset("data/sample_medium.json",
                 generate_parcels(100, 40, seed=11), generate_graph(40, seed=11), capacity=120)
    # larger sample
    save_dataset("data/sample_large.json",
                 generate_parcels(500, 150, seed=21), generate_graph(150, seed=21), capacity=300)
    print("Datasets created in data/")
